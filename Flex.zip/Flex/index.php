<?php
    // Redirect to Login Page 
    include 'login.php';
?>