<!-- THESE ALL ARE FOOTER CONTENTS -- -->

<!-- Footer Start -->
<footer>
    <div class="footer">
        <h5><a href="" target="_blank">Terms of Use</a>
            &copy; Developed by <a href="./aboutUs.php" target="_blank">Agent One</a> </h5>
            <!-- target _blank is used for when i clik the anchor tag it open in a new tab -->
            <!-- &copy; is used for copyright sign -->
    </div>
</footer>
<!-- Footer End -->