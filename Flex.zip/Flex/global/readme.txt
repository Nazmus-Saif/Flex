In this folder there are some common php file which are used in all pages
2 header file is created because some pages have little bit differences